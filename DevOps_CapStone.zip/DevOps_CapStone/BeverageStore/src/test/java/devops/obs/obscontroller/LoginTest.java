package devops.obs.obscontroller;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.*;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import devops.obs.obscontroller.UserLoginController;


public class LoginTest extends Mockito{
	@Mock
	 HttpServletRequest request;
	 @Mock
	 HttpServletResponse response;
	 @Mock
	 HttpSession session;
	 @Mock
	 RequestDispatcher rd;
	 @Before
	 public void setUp() throws Exception {
	  MockitoAnnotations.initMocks(this);
	 }

    @Test
    public void testLoginSuccess() throws Exception {
        when(request.getParameter("uName")).thenReturn("arcaxx");
        when(request.getParameter("pass")).thenReturn("1234");
        session = mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getRequestDispatcher("/order.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer);
        new UserLoginController().doPost(request, response);
        verify(rd).forward(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("Login successfull...", result);
      
    }
    
    @Test
    public void testLoginFail() throws Exception {
        when(request.getParameter("uName")).thenReturn("arcaxxA");
        when(request.getParameter("pass")).thenReturn("12345");
        session = mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getRequestDispatcher("/index.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer);
        new UserLoginController().doPost(request, response);
        verify(rd).include(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("Enter Valid Email and Password", result);
      
    }
    
    @Test
    public void testLoginempty() throws Exception {
        when(request.getParameter("uName")).thenReturn("");
        when(request.getParameter("pass")).thenReturn("");
        session = mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getRequestDispatcher("/index.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer);
        new UserLoginController().doPost(request, response);
        verify(rd).include(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("<font color=red>Please fill all the fields</font>",result);
      
    }

    
}