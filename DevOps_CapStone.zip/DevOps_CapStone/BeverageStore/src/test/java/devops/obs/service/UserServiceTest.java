package devops.obs.service;

import static org.junit.Assert.*;

import org.junit.Test;

import devops.obs.model.User;

public class UserServiceTest {

	@Test
	public void testIsAutherozied() {
		User u1=new User("Archana","Mehra","arcaxx","1234","archana.mehra@wipro.com");
		assertEquals(true,new UserService().isAuthorized(u1));
	}

	@Test
	public void testUpdatePassword() {
		User u1=new User("","","arcaxx","9876","");
		assertEquals(true,new UserService().updatePassword(u1));
	}

	@Test
	public void testDoRegistration() {
		User u1=new User("RAM","RAJ","RMRJ","1234","raj@wipro.com");
		assertEquals(true,new UserService().doRegistration(u1));
	}

}
