package devops.obs.obscontroller;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.*;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;



public class ChangePasswordTest extends Mockito{
	 @Mock
	 HttpServletRequest request;
	 @Mock
	 HttpServletResponse response;
	 @Mock
	 RequestDispatcher rd;
	 @Before
	 public void setUp() throws Exception {
	  MockitoAnnotations.initMocks(this);
	 }

    @Test
    public void testChangePassword() throws Exception {
        when(request.getParameter("uName")).thenReturn("arcaxx");
        when(request.getParameter("pass")).thenReturn("6789");
        when(request.getParameter("confirmpass")).thenReturn("6789");
        when(request.getRequestDispatcher("index.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer); 
        new UserPasswordController().doPost(request, response);
        verify(rd).forward(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("password updated", result);
    }
    
    @Test
    public void passwordempty() throws Exception {
        when(request.getParameter("uName")).thenReturn("");
        when(request.getParameter("pass")).thenReturn("");
        when(request.getParameter("confirmpass")).thenReturn("");
        when(request.getRequestDispatcher("/forgetpassword.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer);
        new UserPasswordController().doPost(request, response);
        //verify(rd).forward(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("<font color=red>Please fill all the fields</font>",result);
      
    }
    
    
     @Test
    public void PasswordMissmatch() throws Exception {
        when(request.getParameter("uName")).thenReturn("arcaxx");
        when(request.getParameter("pass")).thenReturn("6789");
        when(request.getParameter("confirmpass")).thenReturn("67891");
        when(request.getRequestDispatcher("/forgetpassword.jsp")).thenReturn(rd);            
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        when(response.getWriter()).thenReturn(writer); 
        new UserPasswordController().doPost(request, response);
        //verify(rd).forward(request, response);
        String result = stringWriter.getBuffer().toString().trim();
        assertEquals("<font color=red>Password and Confirm Password doen't matches</font>", result);
    }

    
   
}