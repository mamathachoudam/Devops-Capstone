package devops.obs.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
 
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import org.junit.Test;
import org.mockito.Mockito;
import devops.obs.filter.AuthenticationFilter;


import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.*;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;







public class AuthenticationFilterTest extends Mockito{
	@Mock
	 HttpServletRequest request;
	 @Mock
	 HttpServletResponse response;
	 @Mock
	 HttpSession session;
	 @Mock
	 RequestDispatcher rd;
	 @Before
	 public void setUp() throws Exception {
	  MockitoAnnotations.initMocks(this);
	 }
    @Test
    public void testDoFilter() throws Exception {
 
        AuthenticationFilter filter = new AuthenticationFilter(); 
            session = mock(HttpSession.class);
        FilterChain mockFilterChain = Mockito.mock(FilterChain.class);
        FilterConfig mockFilterConfig = Mockito.mock(FilterConfig.class);
        // mock the getRequestURI() response
        Mockito.when(request.getRequestURI()).thenReturn("/");
         BufferedReader br = new BufferedReader(new StringReader("test"));
        // mock the getReader() call
        Mockito.when(request.getReader()).thenReturn(br);
 
        filter.init(mockFilterConfig);
        filter.doFilter(request, response, mockFilterChain);
        filter.destroy();
    }
}
