package devops.obs;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.firefox.FirefoxOptions;

import devops.obs.IntegrationTest;

import org.junit.*;
import static org.junit.Assert.*;

import java.io.File;

import org.junit.experimental.categories.Category;

@Category(IntegrationTest.class)
public class LoginFunctionalTest {

	static WebDriver driver;

	@BeforeClass
	public static void setup() {
	//	driver = new ChromeDriver();
		// new FirefoxDriver();
		FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless");
        System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        
        driver = new FirefoxDriver(firefoxOptions);
        driver.manage().deleteAllCookies();
	}

	@AfterClass
	public static void cleanUp() {
		driver.quit();
	}

	@Test
	public void loginSuccess() {
        driver.get("http://localhost:6080/BeverageStore");
        WebElement email = driver.findElement(By.name("uName"));
        WebElement pass = driver.findElement(By.name("pass"));
        email.sendKeys("nkumarv3");
        pass.sendKeys("1234");
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        assertTrue(driver.getPageSource().contains("Order Page"));
	}
	
	@Test
	public void loginFail() {
        driver.get("http://localhost:6080/BeverageStore");
        WebElement email = driver.findElement(By.name("uName"));
        WebElement pass = driver.findElement(By.name("pass"));
        //WebElement button = driver.findElement(By.xpath("/html/body/form/div/button"));         
        email.sendKeys("nitin.kumar15@wipro.com");
        pass.sendKeys("1234566666666");
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        assertTrue(driver.getPageSource().contains("Enter Valid "));
	}
	
	@Test
 	public void registrationSuccess() {
        driver.get("http://localhost:6080/BeverageStore/register.jsp");
        WebElement firstname = driver.findElement(By.name("firstname"));
        WebElement lastname = driver.findElement(By.name("lastname"));
        WebElement uname  = driver.findElement(By.name("uName"));
        WebElement pass = driver.findElement(By.name("pass"));
        WebElement confirmpass = driver.findElement(By.name("confirmpass"));
        WebElement email = driver.findElement(By.name("email"));
        firstname.sendKeys("fname");
        lastname.sendKeys("lname");
        uname.sendKeys("flname");
        pass.sendKeys("1234");
        confirmpass.sendKeys("1234");
        email.sendKeys("aa@gmail.com");
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        assertTrue(driver.getPageSource().contains("Register"));
	}
	
@Test
	public void forgotPasswordSuccess() {
        driver.get("http://localhost:6080/BeverageStore/forgotpassword.jsp");      
        WebElement email = driver.findElement(By.name("uName"));
        WebElement pass = driver.findElement(By.name("pass"));
        WebElement confirmpass = driver.findElement(By.name("confirmpass"));
        email.sendKeys("arcaxx");
        pass.sendKeys("1234");
        confirmpass.sendKeys("1234");
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        assertTrue(driver.getPageSource().contains("Beverage Store"));
	}
}
