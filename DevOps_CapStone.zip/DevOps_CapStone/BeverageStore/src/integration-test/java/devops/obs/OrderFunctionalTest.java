package devops.obs;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


@Category(IntegrationTest.class)
public class OrderFunctionalTest {
	
	static WebDriver driver;

	@BeforeClass
	public static void setup() {
	
		FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless");
        System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        
        driver = new FirefoxDriver(firefoxOptions);
	}
	
	@AfterClass
	public static void cleanUp() {
		driver.quit();
	}
	
	@Test
	public void orderSuccess() {
        driver.get("http://localhost:6080/BeverageStore/order.jsp");
        List Checkbox = driver.findElements(By.name("items"));
        List<WebElement> options = driver.findElements(By.tagName("option"));
        String value ="";
        for(int i = 0; i< Checkbox.size(); i++) {
        	value = Checkbox.get(i).toString();
        	if(value.equalsIgnoreCase("1005")) {
        		((WebElement) Checkbox.get(i)).click();
        	}
        }
        for(WebElement select : options) {
        	if(select.getText().equals("5")) {
        		select.click();
        		break;
        	}
        }
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        assertTrue(driver.getPageSource().contains("Order"));
	}

}
