

package devops.obs;
public interface IntegrationTest {

	
}
