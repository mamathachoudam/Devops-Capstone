package devops.obs.model;

public class Product {
	
	String product;
	String description;
	double price;
	double discount;
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public Product(String product, String desc, double price, double discount) {
		super();
		this.product = product;
		this.description = desc;
		this.price = price;
		this.discount = discount;
	}
}
