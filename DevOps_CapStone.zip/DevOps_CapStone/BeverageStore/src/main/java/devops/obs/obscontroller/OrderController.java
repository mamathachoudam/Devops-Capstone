package devops.obs.obscontroller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import devops.obs.db.ProductDb;
import devops.obs.model.Order;
import devops.obs.model.Product;

public class OrderController extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String[] selectedVal= request.getParameterValues("items");
		String[] quantity  = request.getParameterValues("quantity");
		
		if(selectedVal == null ){
			response.sendRedirect("order.jsp?msg=Please click on check box and select quantities");
		} 
		else {
			ProductDb product = new ProductDb();
			Order ord;
			ArrayList<Product> prodList = new ArrayList<Product>();
			ArrayList<Order> orderList = new ArrayList<Order>();
			ArrayList<String> quantity1 = new ArrayList<String>();
			Set entrySet = product.productData.entrySet();
			Iterator it = entrySet.iterator();
			while (it.hasNext()) {
				Map.Entry pr = (Map.Entry) it.next();
				prodList.add((Product) pr.getValue());
			}
			for(String quan: quantity){
				if(!quan.isEmpty()){
					quantity1.add(quan);
				}
			}
			if(selectedVal.length == quantity1.size()){
			for (int i = 0; i < selectedVal.length; i++) {
				ord = new Order();
				for (Product productList : prodList) {
					if (selectedVal[i].equals(productList.getProduct())) {
						if (quantity1.get(i) != null || !quantity1.get(i).equals("")) {
							ord.setProduct(productList.getProduct());
							ord.setDescription(productList.getDescription());
							ord.setPrice(productList.getPrice());
							ord.setDiscount(productList.getDiscount());
							ord.setQuantity(Integer.parseInt(quantity1.get(i)));
							ord.setFinalPrice((productList.getPrice()* Integer.parseInt(quantity1.get(i)))
									- (productList.getDiscount() * Integer.parseInt(quantity1.get(i))));

						}
					}					
				}
				if(ord != null)
				orderList.add(ord);
			}
			}
			if (orderList.size() != 0) {
				request.setAttribute("finalOrderList", orderList);
				RequestDispatcher rd = request.getRequestDispatcher("finalorder.jsp");
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("order.jsp?msg=Please select items properly");
			}
		}
	}

}
