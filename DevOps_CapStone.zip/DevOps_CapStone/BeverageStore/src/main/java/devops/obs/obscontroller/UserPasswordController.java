package devops.obs.obscontroller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import devops.obs.model.User;
import devops.obs.service.UserService;

public class UserPasswordController extends HttpServlet {
   @Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String newpass = request.getParameter("pass");
		String confirmpass = request.getParameter("confirmpass");
		String uname = request.getParameter("uName");
try {
		if (newpass.isEmpty() || confirmpass.isEmpty() || uname.isEmpty()) {
			out.println("<font color=red>Please fill all the fields</font>");
			
		} else {
			if (newpass.equals(confirmpass)) {
				User updatePwd = new User("", "",uname,newpass,"");
			    new UserService().updatePassword(updatePwd);
				    RequestDispatcher rd =request.getRequestDispatcher("index.jsp");
					out.println("password updated");
				    rd.forward(request, response);
				
			}
			else {
				out.println("<font color=red>Password and Confirm Password doen't matches</font>");
			}

		}
}
catch(Exception e)
   {
       out.println("Error");
   }
	}
}