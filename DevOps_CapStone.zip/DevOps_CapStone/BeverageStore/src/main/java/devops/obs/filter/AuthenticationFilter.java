package devops.obs.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/AuthenticationFilter")

public class AuthenticationFilter implements javax.servlet.Filter {
private FilterConfig filterConfig;
public void init(final FilterConfig filterConfig)
{
    this.filterConfig = filterConfig;
}
    
public void doFilter(ServletRequest request, ServletResponse response,
       FilterChain chain) 
       throws java.io.IOException, javax.servlet.ServletException
{
    long start = System.currentTimeMillis();
    System.out.println("Milliseconds in: " + start);
    chain.doFilter(request, response);
    long end = System.currentTimeMillis();
    System.out.println("Milliseconds out: " + end);
}


public void destroy()
{
    filterConfig = null;
}
}




