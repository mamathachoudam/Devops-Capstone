package devops.obs.db;

import java.util.HashMap;
import java.util.Map;

import devops.obs.model.Product;

public class ProductDb {
	
	public static Map<String, Product> productData = new HashMap<String, Product>();

	public ProductDb(){
		Product prod1= new Product("1001", "Coca-cola-150ML", 10.5, 2);
		Product prod2= new Product("1002", "Sprite-150ML", 10.5, 1);
		Product prod3= new Product("1003", "Fanta-250ML", 20.5, 1);
		Product prod4= new Product("1004", "Aquafresh-1L", 30, 2);
		Product prod5= new Product("1005", "Coke-Zero", 35, 1);
		
		productData.put(prod1.getProduct(), prod1);
		productData.put(prod2.getProduct(), prod2);
		productData.put(prod3.getProduct(), prod3);
		productData.put(prod4.getProduct(), prod4);
		productData.put(prod5.getProduct(), prod5);
	}
}
